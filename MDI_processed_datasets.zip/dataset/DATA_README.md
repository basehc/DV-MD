# Processed MDI datasets

This package contains the existing processed MDAD, aBiofilm, and DrugVirus files used by `mdi.py`. It does not contain model checkpoints, notebooks, backups, or experiment outputs.

| Dataset | Microbes | Drugs | Unique observed associations |
| --- | ---: | ---: | ---: |
| MDAD | 173 | 1373 | 2470 |
| aBiofilm | 140 | 1720 | 2884 |
| DrugVirus | 95 | 175 | 933 |

## Layout and indexing

Each dataset directory contains:

- `adj.txt`: tab-separated `drug_id microbe_id label` columns. IDs are 1-based and all listed labels are 1. This is an edge list.
- `microbes.txt` and `drugs.txt`: node names, one per line, in ID order.
- `microbes_facts.csv`: columns `taxid`, `scientific_name`, `rank`, `lineage`, `synonyms`, `query_name`, and `semantic_text`.
- `microbes_embeddings.csv`: an index column followed by 1536 numerical embedding columns. Read with `pandas.read_csv(path, index_col=0)`.
- `microbesimilarity.txt`: a square, tab-separated microbial semantic similarity matrix.
- `drugsimilarity.txt`: a square, tab-separated interaction-derived GIP similarity matrix.

Name-file order, embedding row order, and similarity row/column order must be preserved. Unknown pairs are unobserved associations rather than confirmed biological negatives.

## Extraction

From the repository root:

```bash
python -m zipfile -e MDI_processed_datasets.zip .
```

## Version and evaluation scope

The package records the files present on 2026-10-06. These counts identify the packaged data version and should be checked against any manuscript table before claiming exact reproduction.

The supplied GIP similarities were computed from the full observed interaction data. For a training-only evaluation, recompute all interaction-derived similarities using training interactions and construct MDI message-passing edges from training interactions only. The archive itself does not define a train/test split.

`MANIFEST.json` provides dataset counts, file sizes, and SHA-256 hashes for the 21 processed input files. Please acknowledge the original dataset publications and check their applicable terms when redistributing or reusing the data.
